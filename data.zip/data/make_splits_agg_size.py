import pickle
import pandas as pd
import numpy as np
from schnetpack.datasets import QM9
from rdkit import Chem

'''
with open('idx_to_smi.pickle','rb') as f:
    idx_to_smi=pickle.load(f)

def idx_to_df(idx):
    smi=[idx_to_smi[i] for i in idx]
    list1=[qm9data[int(i)][prop1].item() for i in idx]
    list2=[qm9data[int(i)][prop2].item() for i in idx]
    data=pd.DataFrame(list(zip(smi,list1,list2)),columns=['smiles',prop1,prop2])
    return data

qm9data = QM9('../test_eheid/qm9.db', download=True, remove_uncharacterized=True)
length=len(qm9data)
print("loaded qm9")
prop1='gap'
prop2='enthalpy_H'

idx=np.arange(0,length)
df=idx_to_df(idx)
df.to_csv('all.csv',index=False)
'''

df=pd.read_csv('all.csv')
print(df)
df2=df.copy()
df2['N']=[Chem.MolFromSmiles(s).GetNumAtoms() if Chem.MolFromSmiles(s) else 100 for s in df2['smiles']]

#select test small
test_df=df[df2['N']<7]
rest_df=df[df2['N']>=7]
test_df.to_csv("test_agg_size_small.csv",index=False)
print(len(test_df))
test_df2=rest_df.sample(n=len(test_df))
test_df2.to_csv("test_agg_size_large.csv",index=False)
print(len(test_df2))
rest_df=rest_df.drop(test_df2.index)
print(len(rest_df))
for n in [100,300,1000,3000,10000,30000,100000]:
    small=rest_df.sample(n=n)
    val_df=small.sample(frac=0.2)
    train_df=small.drop(val_df.index)
    train_df.to_csv("train_agg_size"+str(n)+".csv",index=False)
    val_df.to_csv("val_agg_size"+str(n)+".csv",index=False)
    

